import { Router } from 'express';
import Task from '../models/Task.js';
import { auth } from '../middleware/auth.js';

const router = Router();

router.get('/', auth, async (req, res) => {
  const tasks = await Task.find({ userId: req.user.id }).sort({ createdAt: -1 });
  res.json(tasks);
});

router.post('/', auth, async (req, res) => {
  const task = await Task.create({ ...req.body, userId: req.user.id });
  res.status(201).json(task);
});

router.put('/:id', auth, async (req, res) => {
  const updated = await Task.findOneAndUpdate({ _id: req.params.id, userId: req.user.id }, req.body, { new: true });
  if (!updated) return res.status(404).json({ error: 'Task not found' });
  res.json(updated);
});

router.delete('/:id', auth, async (req, res) => {
  const del = await Task.findOneAndDelete({ _id: req.params.id, userId: req.user.id });
  if (!del) return res.status(404).json({ error: 'Task not found' });
  res.json({ ok: true });
});

export default router;
