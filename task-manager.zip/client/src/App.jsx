import React, { useState } from 'react'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import Dashboard from './pages/Dashboard.jsx'

export default function App(){
  const [view, setView] = useState('login')
  const [token, setToken] = useState(localStorage.getItem('token') || null)
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('user') || 'null'))

  function onAuth({ token, user }){
    setToken(token); setUser(user)
    localStorage.setItem('token', token)
    localStorage.setItem('user', JSON.stringify(user))
    setView('dashboard')
  }
  function logout(){ localStorage.clear(); setToken(null); setUser(null); setView('login') }

  if(!token){
    return <div className="container">{view==='login'
      ? <Login onSwitch={()=>setView('register')} onSuccess={onAuth} />
      : <Register onSwitch={()=>setView('login')} onSuccess={onAuth} />}</div>
  }
  return <Dashboard token={token} user={user} onLogout={logout} />
}
