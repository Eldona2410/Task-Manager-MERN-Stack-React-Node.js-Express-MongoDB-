import React, { useEffect, useState } from 'react'
import api, { setToken } from '../api.js'
import TaskCard from '../components/TaskCard.jsx'
import TaskForm from '../components/TaskForm.jsx'

export default function Dashboard({ token, user, onLogout }){
  const [tasks,setTasks]=useState([]); const [loading,setLoading]=useState(true); const [filter,setFilter]=useState('all')
  setToken(token)
  async function load(){ setLoading(true); const r=await api.get('/tasks'); setTasks(r.data); setLoading(false) }
  useEffect(()=>{ load() },[])
  async function createTask(d){ const r=await api.post('/tasks',d); setTasks([r.data,...tasks]) }
  async function updateTask(id,d){ const r=await api.put(`/tasks/${id}`,d); setTasks(tasks.map(t=>t._id===id?r.data:t)) }
  async function deleteTask(id){ await api.delete(`/tasks/${id}`); setTasks(tasks.filter(t=>t._id!==id)) }
  const filtered = tasks.filter(t=>filter==='all'?true:t.status===filter)
  return (<div className="container"><div className="topbar"><h2>Hello, {user?.name}</h2><div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">All</option><option value="todo">To Do</option><option value="inprogress">In Progress</option><option value="done">Done</option></select><button onClick={onLogout}>Logout</button></div></div><TaskForm onCreate={createTask} />{loading?<p>Loading…</p>:<div className="grid">{filtered.map(t=>(<TaskCard key={t._id} task={t} onUpdate={updateTask} onDelete={deleteTask} />))}</div>}</div>)
}
