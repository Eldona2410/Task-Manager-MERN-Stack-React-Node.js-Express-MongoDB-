import React, { useState } from 'react'
import api from '../api.js'
export default function Login({ onSwitch, onSuccess }){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [err,setErr]=useState(null)
  async function submit(e){ e.preventDefault(); setErr(null); try{ const r=await api.post('/auth/login',{email,password}); onSuccess(r.data) }catch(e){ setErr(e.response?.data?.error || 'Login failed') } }
  return (<div className="card"><h1>Sign in</h1><form onSubmit={submit}><input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />{err && <div className="error">{err}</div>}<button type="submit">Login</button></form><p>Don't have an account? <a onClick={onSwitch}>Register</a></p></div>)
}
