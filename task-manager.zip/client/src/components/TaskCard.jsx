import React from 'react'
export default function TaskCard({ task, onUpdate, onDelete }){
  function cycleStatus(){ const next=task.status==='todo'?'inprogress':task.status==='inprogress'?'done':'todo'; onUpdate(task._id,{status:next}) }
  return (<div className={`card task ${task.status}`}><div className="task-header"><h4>{task.title}</h4><button onClick={()=>onDelete(task._id)}>✕</button></div>{task.description&&<p>{task.description}</p>}<div className="row"><span className={`pill ${task.priority}`}>{task.priority}</span><span>{task.status}</span><button onClick={cycleStatus}>Next ▶</button></div></div>)
}
