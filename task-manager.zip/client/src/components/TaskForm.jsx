import React, { useState } from 'react'
export default function TaskForm({ onCreate }){
  const [title,setTitle]=useState(''); const [description,setDescription]=useState(''); const [priority,setPriority]=useState('medium'); const [dueDate,setDueDate]=useState('')
  function submit(e){ e.preventDefault(); onCreate({ title, description, priority, dueDate }); setTitle(''); setDescription(''); setPriority('medium'); setDueDate('') }
  return (<form className="card" onSubmit={submit}><h3>Create Task</h3><input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} required /><textarea placeholder="Description" value={description} onChange={e=>setDescription(e.target.value)} /><div className="row"><select value={priority} onChange={e=>setPriority(e.target.value)}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select><input type="date" value={dueDate} onChange={e=>setDueDate(e.target.value)} /><button type="submit">Add</button></div></form>)
}
