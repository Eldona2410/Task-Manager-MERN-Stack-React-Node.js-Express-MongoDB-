# Task Manager (MERN) — Portfolio-Ready

A clean, production-like **Task Manager** built with **React + Node.js + MongoDB**.  
Features JWT auth, CRUD tasks, status workflow (To Do → In Progress → Done), priorities, and a modern UI.

## ✨ Features
- JWT authentication (register/login)
- Create, read, update, delete tasks
- Status cycle: `todo → inprogress → done`
- Priorities, due dates
- Organized MERN structure with `.env.example` files

## 🧱 Tech
- Frontend: React + Vite + Axios
- Backend: Node.js + Express + Mongoose
- DB: MongoDB (local or Atlas)

## 🚀 Run locally

### 1) Backend
```bash
cd server
cp .env.example .env
npm install
npm run dev
```
Edit `.env` if needed (Mongo URI, JWT secret).

### 2) Frontend
```bash
cd ../client
cp .env.example .env
npm install
npm run dev
```
Open http://localhost:5173

## 🧪 Test credentials
Register a new user on the login screen, then log in.

## 📁 Structure
- `server/` — Express API, Mongoose models, auth middleware
- `client/` — React app (login/register/dashboard)

## 🔒 Environment
- **server/.env**
  - `MONGO_URI=mongodb://localhost:27017/task_manager`
  - `JWT_SECRET=supersecretchangeme`
  - `PORT=5000`
  - `CLIENT_ORIGIN=http://localhost:5173`
- **client/.env**
  - `VITE_API_URL=http://localhost:5000/api`

## 📜 License
MIT
